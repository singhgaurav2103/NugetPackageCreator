﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace NugetPackageCreator
{
    public class Dependencies
    {
        public List<DependencyConfiguration> DependencyConfiguration { get; set; }
        public bool AddPackageInIqasWeb { get; set; }
        public bool CreatePackageOfCore { get; set; }
        public bool CreatePackageOfEngine { get; set; }
        public string CurrentVersion { get; set; }
        public bool RebuildBuildIqasWeb { get; set; }
        public bool RebuildScanner { get; set; }
        public string ScannerSolutionTrailingPath { get; set; }
        public string Iqautoscan3SolutionTrailingPath { get; set; }
        public string EngineTrailingPath { get; set; }
        public string CoreTrailingPath { get; set; }
    }
    public class DependencyConfiguration
    { 
        public string ID { get; set; }
        public string TrailingPath { get; set; }
        public bool CreatePackage { get; set; }
        public List<string> DependentPackageIDs { get; set; }
        public bool AddDependentNugetPackage { get; set; }
        [JsonIgnore]
        public int DependentIndegree {  get; set; }  
    }
}
